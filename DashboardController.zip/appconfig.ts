import { AppConfigurationClient } from "@azure/app-configuration";

// Define your Azure App Configuration connection string and configuration key
const configKey = 'YOUR_CONFIG_KEY';
const connectionString = process.env["APPCONFIG_CONNECTION_STRING"] || "<connection string>";
  const client = new AppConfigurationClient(connectionString);
  const result = await client.listConfigurationSettings({ keyFilter: configKey });

// Main function to fetch values and iterate through them



export async function main() {
  console.log(`Running listConfigurationSettings sample`);

  // Set the following environment variable or edit the value on the following line.
  const connectionString = process.env["APPCONFIG_CONNECTION_STRING"] || "<connection string>";
  const client = new AppConfigurationClient(connectionString);

  // ex: using a keyFilter
  const sampleKeys = client.listConfigurationSettings({
    keyFilter: "dashboard*",
  });

  for await (const setting of sampleKeys) {
    console.log(`  Found key: ${setting.key}, label: ${setting.label}`);
  }

  const samplesWithDevelopmentLabel = client.listConfigurationSettings({
    labelFilter: "development*",
  });

  for await (const setting of samplesWithDevelopmentLabel) {
    console.log(`  Found key: ${setting.key}, label: ${setting.label}`);
  }

  // Passing marker as an argument
  let iterator = client.listConfigurationSettings({ keyFilter: "sample*" }).byPage();
  let response = await iterator.next();
  if (!response.done) {
    for (const setting of response.value.items) {
      console.log(`  Found key: ${setting.key}`);
    }
  }

  let marker = response.value.continuationToken;
  iterator = client.listConfigurationSettings({ keyFilter: "sample*" }).byPage({
    continuationToken: marker,
  });
  response = await iterator.next();
  if (response.done) {
    console.log("List done.");
  } else {
    if (response.value.items) {
      for (const setting of response.value.items) {
        console.log(`  Found key: ${setting.key}`);
      }
    }
  }
}

main();