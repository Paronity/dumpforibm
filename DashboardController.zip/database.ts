import pg from 'pg';
interface Result {
  id: number;
  data: any;
}

export class PostgresDatabase {
  private readonly client: pg.Client;

  constructor() {
    //need values for the postgres dbt hat we get to go here - they will be pulled from the config, obviously. 
    this.client = new pg.Client({
      user: 'your_username',
      host: 'localhost',
      database: 'your_database_name',
      password: 'your_password',
      port: 5432, // Change if your PostgreSQL instance uses a different port
    });
    this.client.connect();
  }

  async create(data: any): Promise<Result> {
    const query = 'INSERT INTO results_log(data) VALUES($1) RETURNING *';
    const values = [data];
    const result = await this.client.query(query, values);
    return result.rows[0];
  }

  async readAll(): Promise<Result[]> {
    const query = 'SELECT * FROM results_log';
    const result = await this.client.query(query);
    return result.rows;
  }

  async readById(id: number): Promise<Result | undefined> {
    const query = 'SELECT * FROM results_log WHERE id = $1';
    const values = [id];
    const result = await this.client.query(query, values);
    return result.rows[0];
  }

  async updateById(id: number, newData: any): Promise<Result | undefined> {
    const query = 'UPDATE results_log SET data = $1 WHERE id = $2 RETURNING *';
    const values = [newData, id];
    const result = await this.client.query(query, values);
    return result.rows[0];
  }

  async deleteById(id: number): Promise<boolean> {
    const query = 'DELETE FROM results_log WHERE id = $1';
    const values = [id];
    const result = await this.client.query(query, values);
    if(typeof result!='undefined' && result){
      if(result.rowCount == 0)
        {
          return false;
        }
        return true
   }
    return false;
  }

  async close(): Promise<void> {
    await this.client.end();
  }
}


