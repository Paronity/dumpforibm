import {ConfigurableTimer} from "./timer.js";
import {PostgresDatabase} from "./database.js";
import express, { Request, Response } from 'express';

//listening stuff for the api endpoints
const app = express();
const port = 3000; // Change this to your desired port number

// Define your endpoint route
app.get('/api/refreshURL', (req: Request, res: Response) => {
  //this endpoint will allow the user to trigger a refresh of a single URL

});

app.get('/api/getLatestStats', (req: Request, res: Response) => {
  //this endpoint will fetch the latest stats, as cached by the database

});


// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

var urlTimer = new ConfigurableTimer(refreshAllURLs,60000)
urlTimer.start();

//you can pass any void rerturning function to the timer class to be called when the timer elapses. 
function refreshAllURLs()
{
  //iterate through each URL and stage the results in cache. 
}

//=================examples=========================
// timer class usage:
const timer = new ConfigurableTimer(() => {
    console.log('Timer elapsed!');
  }, 1000); 
  timer.start(); // Start the timer
  // Change the interval after 3 seconds
  setTimeout(() => {
    timer.setInterval(2000);
  }, 3000);
  

  setTimeout(() => {
    timer.stop(); 
  }, 10000);


//database examples:
const db = new PostgresDatabase();
// Create a new result
const result1 = await db.create({ key: 'value' });
console.log('Created result:', result1);

// Read all
const allResults = await db.readAll();
console.log('All results:', allResults);

// Read a single
const resultById = await db.readById(result1.id);
console.log('Result by id:', resultById);

// Update a result
const updatedResult = await db.updateById(result1.id, { key: 'new value' });
console.log('Updated result:', updatedResult);

// Delete a result
const isDeleted = await db.deleteById(result1.id);
console.log('Is deleted:', isDeleted);
console.log('All results after deletion:', await db.readAll());
db.close();
