export class ConfigurableTimer {
    private intervalId: NodeJS.Timeout | null = null;
  
    constructor(private callback: () => void, private interval: number) {}
  
    start() {
      if (this.intervalId === null) {
        this.intervalId = setInterval(() => {
          this.callback();
        }, this.interval);
      }
    }
  
    stop() {
      if (this.intervalId !== null) {
        clearInterval(this.intervalId);
        this.intervalId = null;
      }
    }
  
    restart() {
      this.stop();
      this.start();
    }
  
    setInterval(interval: number) {
      this.interval = interval;
      if (this.intervalId !== null) {
        this.restart();
      }
    }
  }